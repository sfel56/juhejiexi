const $ = (id) => document.getElementById(id)

const API_KEY = 'd43852fddeb32d123068db8da0e81b7f'

const els = {
  videoUrl: $('videoUrl'),
  parseBtn: $('parseBtn'),
  btnText: $('parseBtn').querySelector('.btn-text'),
  spinner: $('parseBtn').querySelector('.spinner'),
  resultPanel: $('resultPanel'),
  platformBadge: $('platformBadge'),
  resultTitle: $('resultTitle'),
  resultCard: $('resultCard'),
  cover: $('cover'),
  player: $('player'),
  videoEmpty: $('videoEmpty'),
  videoTitle: $('videoTitle'),
  author: $('author'),
  like: $('like'),
  time: $('time'),
  platform: $('platform'),
  downloadBtn: $('downloadBtn'),
  copyBtn: $('copyBtn'),
  albumCard: $('albumCard'),
  albumCover: $('albumCover'),
  albumTitle: $('albumTitle'),
  albumAuthor: $('albumAuthor'),
  albumLike: $('albumLike'),
  albumCount: $('albumCount'),
  albumPlatform: $('albumPlatform'),
  albumGallery: $('albumGallery'),
  rawJson: $('rawJson'),
  errorPanel: $('errorPanel'),
  errorMsg: $('errorMsg'),
}

const PLATFORM_COLOR = {
  '抖音': '#fe2c55',
  '快手': '#ff6b00',
  '哔哩哔哩': '#00a1d6',
}

els.parseBtn.addEventListener('click', parse)

els.videoUrl.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') parse()
})

const URL_PATTERN = /https?:\/\/[^\s"'<>，。；、！？（）【】「」《》\u4e00-\u9fff]+/g
const PRIORITY_HOSTS = [
  'v.douyin.com', 'v.kuaishou.com', 'b23.tv', 'www.bilibili.com',
  'bilibili.com', 'douyin.com', 'kuaishou.com', 'iesdouyin.com', 'f.kuaishou.com',
]

function extractUrl(text) {
  if (!text) return ''
  const clean = (u) => u.replace(/[),.。，、;；!！?？]+$/, '').replace(/^[\[【(（]+/, '')
  const urls = (text.match(URL_PATTERN) || []).map(clean)
  if (!urls.length) return ''
  for (const host of PRIORITY_HOSTS) {
    const hit = urls.find((u) => u.includes(host))
    if (hit) return hit
  }
  return urls[0]
}

async function parse() {
  const raw = els.videoUrl.value.trim()
  const url = extractUrl(raw) || raw

  hide(els.errorPanel)
  hide(els.resultPanel)

  if (!url) {
    return showError('请输入或粘贴包含视频链接的分享文案')
  }

  setLoading(true)

  try {
    const resp = await fetch(`/api/video_qsy/juhe?url=${encodeURIComponent(url)}&apiKey=${encodeURIComponent(API_KEY)}`)
    const data = await resp.json()

    if (data.status === 1 && data.data) {
      render(data)
    } else {
      showError(data.msg || data.message || '解析失败，请检查链接与密钥')
    }
  } catch (err) {
    showError('请求出错：' + err.message)
  } finally {
    setLoading(false)
  }
}

function render(data) {
  const d = data.data || {}
  const meta = data.meta || {}
  const platform = meta.platform || '未知'

  els.platformBadge.textContent = platform
  els.platformBadge.style.background = PLATFORM_COLOR[platform] || '#6b7280'
  els.rawJson.textContent = JSON.stringify(data, null, 2)

  hideVideoUI()
  hide(els.albumCard)

  if (d.album_info) {
    els.resultTitle.textContent = '图集解析结果'
    renderAlbum(d.album_info, platform)
    show(els.albumCard)
  } else {
    els.resultTitle.textContent = '解析结果'
    renderVideo(d.video_info || {}, platform)
    show(els.resultCard)
  }

  show(els.resultPanel)
  els.resultPanel.scrollIntoView({ behavior: 'smooth', block: 'start' })
}

function hideVideoUI() {
  try { els.player.pause() } catch (e) {}
  els.player.removeAttribute('src')
  els.player.load()
  els.player.hidden = true
  els.videoEmpty.hidden = true
  els.cover.hidden = true
  els.downloadBtn.hidden = true
  els.copyBtn.hidden = true
}

function renderVideo(info, platform) {
  els.videoTitle.textContent = info.title || '无标题'
  els.author.textContent = info.author || '-'
  els.like.textContent = formatNumber(info.like) || '-'
  els.time.textContent = info.time || '-'
  els.platform.textContent = platform
  els.copyBtn.hidden = false

  // 封面图（独立展示）
  if (info.cover) {
    els.cover.src = info.cover
    els.cover.hidden = false
  } else {
    els.cover.src = ''
    els.cover.hidden = true
  }

  // 视频预览（独立区域）
  const hasVideo = info.url || info.download

  if (hasVideo) {
    const proxyUrl = '/proxy?url=' + encodeURIComponent(info.download || info.url)
    els.player.src = proxyUrl
    els.player.hidden = false
    els.videoEmpty.hidden = true
    els.downloadBtn.href = proxyUrl
    els.downloadBtn.hidden = false
  } else {
    els.player.src = ''
    els.player.hidden = true
    els.videoEmpty.hidden = false
    els.downloadBtn.hidden = true
  }
}

function renderAlbum(info, platform) {
  const images = Array.isArray(info.images) ? info.images : []

  els.albumTitle.textContent = info.title || '无标题'
  els.albumAuthor.textContent = info.author || '-'
  els.albumLike.textContent = formatNumber(info.like) || '-'
  els.albumCount.textContent = (info.count || images.length) + ' 张'
  els.albumPlatform.textContent = platform

  if (info.cover) {
    els.albumCover.src = '/proxy?url=' + encodeURIComponent(info.cover)
    els.albumCover.hidden = false
  } else {
    els.albumCover.src = ''
    els.albumCover.hidden = true
  }

  els.albumGallery.innerHTML = ''
  if (!images.length) {
    const empty = document.createElement('div')
    empty.className = 'media-empty'
    empty.textContent = '无图片数据'
    els.albumGallery.appendChild(empty)
    return
  }

  images.forEach((src, i) => {
    const proxyUrl = '/proxy?url=' + encodeURIComponent(src)
    const figure = document.createElement('figure')
    figure.className = 'album-item'

    const img = document.createElement('img')
    img.src = proxyUrl
    img.alt = '图集第 ' + (i + 1) + ' 张'
    img.loading = 'lazy'

    const caption = document.createElement('figcaption')
    const label = document.createElement('span')
    label.textContent = '第 ' + (i + 1) + ' / ' + images.length + ' 张'
    const link = document.createElement('a')
    link.href = proxyUrl
    link.download = ''
    link.target = '_blank'
    link.rel = 'noopener'
    link.textContent = '下载原图'
    caption.appendChild(label)
    caption.appendChild(link)

    figure.appendChild(img)
    figure.appendChild(caption)
    els.albumGallery.appendChild(figure)
  })
}

els.copyBtn.addEventListener('click', async () => {
  const href = els.downloadBtn.getAttribute('href')
  if (!href) return
  try {
    await navigator.clipboard.writeText(location.origin + href)
    els.copyBtn.textContent = '已复制 ✓'
    setTimeout(() => { els.copyBtn.textContent = '复制下载链接' }, 1600)
  } catch {
    showError('复制失败，请手动复制')
  }
})

function showError(msg) {
  els.errorMsg.textContent = msg
  show(els.errorPanel)
  els.errorPanel.scrollIntoView({ behavior: 'smooth', block: 'start' })
}

function setLoading(loading) {
  els.parseBtn.disabled = loading
  els.spinner.hidden = !loading
  els.btnText.textContent = loading ? '解析中...' : '开始解析'
}

function formatNumber(n) {
  if (n === undefined || n === null || n === '') return '-'
  n = Number(n)
  if (isNaN(n)) return '-'
  if (n >= 100000000) return (n / 100000000).toFixed(1).replace(/\.0$/, '') + ' 亿'
  if (n >= 10000) return (n / 10000).toFixed(1).replace(/\.0$/, '') + ' 万'
  return String(n)
}

function show(el) { el.hidden = false }
function hide(el) { el.hidden = true }
