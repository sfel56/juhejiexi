import express from 'express'
import path from 'path'
import { fileURLToPath } from 'url'
import { createServer } from 'http'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const PORT = process.env.PORT || 3000
const API_BASE = 'https://api.xcvts.cn'

const app = express()
app.use(express.static(path.join(__dirname, 'public')))

app.get('/api/video_qsy/juhe', async (req, res) => {
  const { url, apiKey } = req.query
  if (!url || !apiKey) {
    return res.status(400).json({ status: 0, msg: '缺少参数：url 与 apiKey 均为必填' })
  }
  try {
    const target = `${API_BASE}/api/video_qsy/juhe?url=${encodeURIComponent(url)}&apiKey=${encodeURIComponent(apiKey)}`
    const resp = await fetch(target, { headers: { 'user-agent': 'Mozilla/5.0' } })
    const text = await resp.text()
    try {
      res.json(JSON.parse(text))
    } catch {
      res.json({ status: 0, msg: text || `上游返回 ${resp.status}` })
    }
  } catch (err) {
    res.status(502).json({ status: 0, msg: '代理请求失败：' + err.message })
  }
})

app.get('/proxy', async (req, res) => {
  const { url } = req.query
  if (!url) return res.status(400).send('missing url')
  try {
    const resp = await fetch(url, {
      headers: {
        'user-agent': 'Mozilla/5.0',
        'referer': 'https://www.douyin.com/',
      },
      redirect: 'follow',
    })
    if (!resp.ok && resp.status !== 206) {
      return res.status(resp.status).send('proxy failed: ' + resp.status)
    }
    res.setHeader('content-type', resp.headers.get('content-type') || 'application/octet-stream')
    res.setHeader('accept-ranges', 'bytes')
    res.setHeader('cache-control', 'no-store')
    if (resp.headers.get('content-length')) {
      res.setHeader('content-length', resp.headers.get('content-length'))
    }
    const reader = resp.body.getReader()
    while (true) {
      const { done, value } = await reader.read()
      if (done) break
      res.write(value)
    }
    res.end()
  } catch (err) {
    res.status(502).send('proxy error: ' + err.message)
  }
})

const server = createServer(app)
server.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`)
})
