export async function onRequestGet(context) {
  const url = new URL(context.request.url)
  const targetUrl = url.searchParams.get('url')

  if (!targetUrl) {
    return new Response('missing url', { status: 400 })
  }

  try {
    const resp = await fetch(targetUrl, {
      headers: {
        'user-agent': 'Mozilla/5.0',
        'referer': 'https://www.douyin.com/'
      },
      redirect: 'follow'
    })

    if (!resp.ok && resp.status !== 206) {
      return new Response('proxy failed: ' + resp.status, { status: resp.status })
    }

    const headers = new Headers()
    headers.set('content-type', resp.headers.get('content-type') || 'application/octet-stream')
    headers.set('accept-ranges', 'bytes')
    headers.set('cache-control', 'no-store')

    const contentLength = resp.headers.get('content-length')
    if (contentLength) {
      headers.set('content-length', contentLength)
    }

    return new Response(resp.body, {
      status: 200,
      headers
    })
  } catch (err) {
    return new Response('proxy error: ' + err.message, { status: 502 })
  }
}
