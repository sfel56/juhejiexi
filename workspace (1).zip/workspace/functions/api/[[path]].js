const API_BASE = 'https://api.xcvts.cn'

export async function onRequestGet(context) {
  const url = new URL(context.request.url)
  const path = context.params.path || ''

  if (path === 'video_qsy/juhe') {
    const apiKey = url.searchParams.get('apiKey')
    const videoUrl = url.searchParams.get('url')

    if (!videoUrl || !apiKey) {
      return new Response(
        JSON.stringify({ status: 0, msg: '缺少参数：url 与 apiKey 均为必填' }),
        {
          status: 400,
          headers: { 'content-type': 'application/json' }
        }
      )
    }

    try {
      const target = `${API_BASE}/api/video_qsy/juhe?url=${encodeURIComponent(videoUrl)}&apiKey=${encodeURIComponent(apiKey)}`
      const resp = await fetch(target, {
        headers: { 'user-agent': 'Mozilla/5.0' }
      })
      const text = await resp.text()

      let data
      try {
        data = JSON.parse(text)
      } catch {
        data = { status: 0, msg: text || `上游返回 ${resp.status}` }
      }

      return new Response(JSON.stringify(data), {
        status: 200,
        headers: { 'content-type': 'application/json' }
      })
    } catch (err) {
      return new Response(
        JSON.stringify({ status: 0, msg: '代理请求失败：' + err.message }),
        {
          status: 502,
          headers: { 'content-type': 'application/json' }
        }
      )
    }
  }

  return new Response('Not Found', { status: 404 })
}
